#
#   tkmngfocus.rb - load tk/mngfocus.rb
#
require 'tk/mngfocus'
