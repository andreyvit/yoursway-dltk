#
#   tkwinpkg.rb - load tk/winpkg.rb
#
require 'tk/winpkg'
