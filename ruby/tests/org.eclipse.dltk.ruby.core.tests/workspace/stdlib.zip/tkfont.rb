#
#   tkfont.rb - load tk/font.rb
#
require 'tk/font'
