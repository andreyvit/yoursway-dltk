require 'test/minirunit'

test_check "Test __LINE__"

require 'test/testLine_comment.rb'
require 'test/testLine_block_comment.rb'
require 'test/testLine_mixed_comment.rb'
require 'test/testLine_block_comment_start.rb'
require 'test/testLine_line_comment_start.rb'
require 'test/testLine_code.rb'
