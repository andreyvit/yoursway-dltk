test_equal(1, __LINE__)
=begin
=end
test_equal(4, __LINE__)
=begin
#=end
=end
test_equal(8, __LINE__)
