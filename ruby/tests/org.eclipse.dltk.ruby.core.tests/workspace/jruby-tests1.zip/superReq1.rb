class SuperOne
end