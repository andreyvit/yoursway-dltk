# Intentionally try to require missing library; to test what happens when we require this file
require 'bogus_missing_lib'