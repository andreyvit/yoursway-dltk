if $loadTest
  $loadTest+=1
else
  $loadTest = 0
end
puts $loadTest
