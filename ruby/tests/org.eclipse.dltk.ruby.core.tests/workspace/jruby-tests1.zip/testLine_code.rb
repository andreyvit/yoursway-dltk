test_equal(1, __LINE__)
foo = 1
test_equal(3, __LINE__)
