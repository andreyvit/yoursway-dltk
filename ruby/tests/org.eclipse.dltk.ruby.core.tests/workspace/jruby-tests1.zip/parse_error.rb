# Intentional parse error -- to test what happens when we require this file
class Foo
end
end