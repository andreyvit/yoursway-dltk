=begin
line 2
=end
test_equal(4, __LINE__)


