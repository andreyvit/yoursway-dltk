require 'test/testLowerJavaSupport'
puts
require 'test/testHigherJavaSupport'
puts
require 'test/testInstantiatingInterfaces'
puts
test_print_report

