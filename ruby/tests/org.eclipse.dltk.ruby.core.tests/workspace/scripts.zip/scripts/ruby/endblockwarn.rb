def end1
  END {}
end

end1

eval <<EOE
  def end2
    END {}
  end
EOE

